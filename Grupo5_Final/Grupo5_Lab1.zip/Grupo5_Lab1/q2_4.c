    int f1(int x) { 
        return x * 4; 
    } 
    int f2(int x) { 
        return x << 2; 
    } 

    int f3(int x) { 
        return x + x + x + x; 
    } 